PIXEL FILMS — Free starter website

FILES
- index.html: complete responsive website.

HOW TO EDIT
1. Open index.html in a text editor.
2. Find the MOVIES list near the bottom.
3. Replace the sample titles, categories, years and descriptions.
4. Add a direct video URL in video: "https://.../your-video.mp4"
5. Add a direct download URL in download: "https://.../your-file.mp4"
6. Save and open index.html in a browser to preview.

IMPORTANT
- The sample movie cards are placeholders; they do not contain films.
- Video playback needs a direct MP4/HLS URL from a host that allows embedding (CORS/hotlink rules may apply).
- A download button appears only when a download URL is supplied.
- Use only videos you created, own, or have permission to distribute.
- This is a static website. It has no secure admin panel, user accounts, database, or video storage.
- The movie list is edited in the HTML file. For public updates, upload the changed file again.
- Free static hosting can publish the website, but video storage/bandwidth may have separate limits.
